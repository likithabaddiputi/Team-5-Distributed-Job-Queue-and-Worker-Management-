# SDN + Mininet Environment
## Distributed Job Queue and Worker Management

### Architecture

Ryu Controller
      |
  OpenFlow 1.3
      |
     s1
  ┌───┼────┬────┐
  h1  h2   h3   h4
 Client Coordinator Worker1 Worker2

### Node Configuration

| Node | Role | IP Address |
|------|------|------------|
| h1 | Client | 10.0.0.1 |
| h2 | Coordinator | 10.0.0.2 |
| h3 | Worker 1 | 10.0.0.3 |
| h4 | Worker 2 | 10.0.0.4 |

Switch:
- s1 = Open vSwitch
- OpenFlow version = 1.3

Controller:
- Ryu
- Address = 127.0.0.1
- OpenFlow port = 6633

### Starting the SDN Environment

#### Terminal 1 - Ryu

```bash
source ~/ryu-env/bin/activate
cd ~/sdn-project
ryu-manager controller.py
