import socket
import sys

COORDINATOR_HOST = '10.0.0.2'
COORDINATOR_PORT = 6000


def recv_line(conn):
    data = b""
    while b"\n" not in data:
        part = conn.recv(1024)
        if not part:
            return None
        data += part
    line = data.split(b"\n")[0]
    return line.decode()


def send_line(conn, text):
    conn.send((text + "\n").encode())


def main():
    if len(sys.argv) < 2:
        print("Usage: python3 simple_client.py <number>")
        return
    n_value = sys.argv[1]

    print("=" * 50)
    print("   JOB CLIENT")
    print("=" * 50)
    print()

    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(3)
    last_err = None
    for attempt in range(1, 16):
        try:
            s.connect((COORDINATOR_HOST, COORDINATOR_PORT))
            last_err = None
            break
        except OSError as e:
            last_err = e
            print("[CLIENT] connect attempt %d/15 failed: %s" % (attempt, e))
            s.close()
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(3)
            import time
            time.sleep(1)
    if last_err is not None:
        print("[CLIENT] giving up: cannot reach coordinator at %s:%s" % (COORDINATOR_HOST, COORDINATOR_PORT))
        raise last_err
    s.settimeout(None)

    print("[CLIENT] Submitting job (n = " + n_value + ")")
    send_line(s, "SUBMIT|" + n_value)

    ack = recv_line(s)
    job_id = ack.split("|")[1]
    print("[CLIENT] Coordinator accepted it -> job ID:", job_id)
    print()
    print("[CLIENT] Waiting for result...")
    print()

    result_msg = recv_line(s)
    parts = result_msg.split("|")
    print("[CLIENT] RESULT for", parts[1], "=", parts[2])
    print()

    s.close()


if __name__ == "__main__":
    main()
